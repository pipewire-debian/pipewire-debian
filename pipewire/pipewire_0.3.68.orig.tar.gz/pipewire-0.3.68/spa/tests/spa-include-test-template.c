#include <@INCLUDE@>

int main(void) {
	return 0;
}
