<!-- If you are filing this issue with a regular release please try master as it might already be fixed. -->

<!-- If you can, test also with Pulseaudio and list `pulseaudio --version`. -->

- PipeWire version (`pipewire --version`):
- Distribution and distribution version (`PRETTY_NAME` from `/etc/os-release`):
- Desktop Environment:
- Kernel version (`uname -r`):
- BlueZ version (`bluetoothctl --version`):
- `lsusb`:
```
# paste the output of "lsusb" here
```
- Bluetooth devices:

```
# paste the output of "bluetoothctl devices" here
```

## Description of Problem:


## How Reproducible:


### Steps to Reproduce:


 1.
 2.
 3.


### Actual Results:


### Expected Results:


# Additional Info (as attachments):

 - `pw-dump > pw-dump.log`:
 - Bluetooth debug log, see [here](https://gitlab.freedesktop.org/pipewire/pipewire/-/wikis/Troubleshooting#bluetooth):
