#include <errno.h>

#include "registry.h"

int do_extension_device_manager(struct client *client, uint32_t tag, struct message *m)
{
	return -ENOTSUP;
}
