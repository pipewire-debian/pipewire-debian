If you are filing this issue with a regular release please try master as it might already be fixed. Also test with PulseAudio because if it doesn't work there it's not going to here either.

Bluetooth Radio, Bluetooth Headset, Desktop Environment, Distribution, Version (Bluez, Kernel, and PipeWire):


Description of Problem:


How Reproducible:


Steps to Reproduce:


 1.
 2.
 3.


Actual Results:


Expected Results:


Additional Info Eg. Additional Kernel Patches, `pw-dump -N > file` (As Attachment Please):
