If you are filing this issue with a regular release please try master as it might already be fixed.

Version, Distribution, Desktop Environment:


Description of Problem:


How Reproducible:


Steps to Reproduce:
 
 1.
 2.
 3.


Actual Results:


Expected Results:


Additional Info Eg. `pw-dump -N > file` (As Attachment Please):
