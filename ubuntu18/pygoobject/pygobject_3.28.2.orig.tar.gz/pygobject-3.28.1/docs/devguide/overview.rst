========
Overview
========


See :doc:`/bugs_repo` for information on where to find the bug tracker and the
source code.

Continuous Testing
------------------

The test suite gets regularly run on all supported platforms using
https://github.com/pygobject/pygobject-ci

There is currently no integration with the git repo for this and the status
has to be checked manually.
