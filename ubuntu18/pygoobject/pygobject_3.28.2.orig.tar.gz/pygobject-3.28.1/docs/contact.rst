=======
Contact
=======

**IRC**
    #python on irc.gnome.org

    Logs for the channel: https://quodlibet.duckdns.org/irc/pygobject

**Mailinglist**
    https://mail.gnome.org/mailman/listinfo/python-hackers-list
