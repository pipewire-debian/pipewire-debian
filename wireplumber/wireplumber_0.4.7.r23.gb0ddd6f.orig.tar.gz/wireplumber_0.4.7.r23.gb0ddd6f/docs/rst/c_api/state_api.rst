.. _state_api:

State Storage
=============
.. graphviz::
  :align: center

   digraph inheritance {
      rankdir=LR;
      GObject -> WpState;
   }

.. doxygenstruct:: WpState

.. doxygengroup:: wpstate
   :content-only:
