.. _releases:

Releases
========

.. include:: ../../NEWS.rst
