.. _spa_json_api:

Spa Json
========
.. graphviz::
  :align: center

   digraph inheritance {
      rankdir=LR;
      GBoxed -> WpSpaJson;
      GBoxed -> WpSpaJsonBuilder;
      GBoxed -> WpSpaJsonParser;
   }

.. doxygenstruct:: WpSpaJson

.. doxygenstruct:: WpSpaJsonBuilder

.. doxygenstruct:: WpSpaJsonParser

.. doxygengroup:: wpspajson
   :content-only:
