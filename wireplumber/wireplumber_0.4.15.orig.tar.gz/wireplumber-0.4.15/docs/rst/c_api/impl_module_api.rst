.. _impl_module_api:

Local Modules
=============

.. graphviz::
  :align: center

   digraph inheritance {
      rankdir=LR;
      GObject -> WpImplModule;
   }

.. doxygenstruct:: WpImplModule
   :members:

.. doxygengroup:: wpimplmodule
   :content-only:
