.. _obj_interest_api:

Object Interest
===============
.. graphviz::
  :align: center

   digraph inheritance {
      rankdir=LR;
      GBoxed -> WpObjectInterest;
   }

.. doxygenstruct:: WpObjectInterest

.. doxygengroup:: wpobjectinterest
   :content-only:
