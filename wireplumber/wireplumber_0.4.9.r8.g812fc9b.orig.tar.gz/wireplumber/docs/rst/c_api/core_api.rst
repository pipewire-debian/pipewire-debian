.. _core_api:

Core
====
.. graphviz::
  :align: center

   digraph inheritance {
      rankdir=LR;
      GObject -> WpCore;
   }

.. doxygenstruct:: WpCore

.. doxygengroup:: wpcore
   :content-only:
