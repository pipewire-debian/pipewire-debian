.. _iterator_api:

Iterator
========
.. graphviz::
  :align: center

   digraph inheritance {
      rankdir=LR;
      GBoxed -> WpIterator;
   }

.. doxygenstruct:: WpIterator

.. doxygenstruct:: _WpIteratorMethods

.. doxygengroup:: wpiterator
   :content-only:
