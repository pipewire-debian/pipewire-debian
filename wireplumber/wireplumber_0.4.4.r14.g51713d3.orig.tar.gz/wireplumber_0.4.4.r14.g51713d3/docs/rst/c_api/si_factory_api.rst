.. _si_factory_api:

Session Items Factory
=====================
.. graphviz::
  :align: center

   digraph inheritance {
      rankdir=LR;
      GObject -> WpSiFactory;
   }

.. doxygenstruct:: WpSiFactory

.. doxygenstruct:: _WpSiFactoryClass

.. doxygengroup:: wpsifactory
   :content-only:
