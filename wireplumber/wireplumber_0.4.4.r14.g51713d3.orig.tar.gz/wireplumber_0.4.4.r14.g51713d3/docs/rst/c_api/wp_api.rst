.. _wp_api:

Library Initialization
======================
.. doxygengroup:: wp
   :content-only:
