.. _log_api:

Debug Logging
=============
.. doxygengroup:: wplog
   :content-only:
