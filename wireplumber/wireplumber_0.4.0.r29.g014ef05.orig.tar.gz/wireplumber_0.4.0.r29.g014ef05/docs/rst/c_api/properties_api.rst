.. _properties_api:

Properties Dictionary
=====================
.. graphviz::
  :align: center

   digraph inheritance {
      rankdir=LR;
      GBoxed -> WpProperties;
   }

.. doxygenstruct:: WpProperties

.. doxygengroup:: wpproperties
   :content-only:
