.. _object_api:

WpObject
========
.. graphviz::
  :align: center

   digraph inheritance {
      rankdir=LR;
      GObject -> WpObject;
   }

.. doxygenstruct:: WpObject

.. doxygenstruct:: _WpObjectClass

.. doxygengroup:: wpobject
   :content-only:
