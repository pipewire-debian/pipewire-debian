.. _session_item_api:

Session Items
=============
.. graphviz::
  :align: center

   digraph inheritance {
      rankdir=LR;
      GObject -> WpObject;
      WpObject -> WpSessionItem;
   }

.. doxygenstruct:: WpSessionItem

.. doxygenstruct:: _WpSessionItemClass

.. doxygengroup:: wpsessionitem
   :content-only:
