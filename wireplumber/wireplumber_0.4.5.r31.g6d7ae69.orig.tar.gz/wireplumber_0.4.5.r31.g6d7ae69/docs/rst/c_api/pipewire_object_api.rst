.. _pipewire_object_api:

PipeWire Object
===============
.. graphviz::
  :align: center

   digraph inheritance {
      rankdir=LR;
      GInterface -> WpPipewireObject;
   }

.. doxygenstruct:: WpPipewireObject

.. doxygenstruct:: _WpPipewireObjectInterface

.. doxygengroup:: wppipewireobject
   :content-only:
