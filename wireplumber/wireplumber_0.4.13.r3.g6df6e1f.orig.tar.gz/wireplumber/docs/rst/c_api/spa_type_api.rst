.. _spa_type_api:

Spa Type Information
====================
.. doxygengroup:: wpspatype
