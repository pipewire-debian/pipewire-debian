 .. _lua_object_api:

WpObject
========
