.. _obj_manager_api:

Object Manager
==============
.. graphviz::
  :align: center

   digraph inheritance {
      rankdir=LR;
      GObject -> WpObjectManager;
   }

.. doxygenstruct:: WpObjectManager

.. doxygengroup:: wpobjectmanager
   :content-only:
