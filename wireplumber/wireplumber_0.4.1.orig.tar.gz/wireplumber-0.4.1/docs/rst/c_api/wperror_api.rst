.. _wperror_api:

Error Codes
===========
.. doxygengroup:: wperror
   :content-only:
