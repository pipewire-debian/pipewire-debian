# -*- coding: utf-8 -*-

import datetime
import os
import re
import subprocess
import sys

def get_version():
    proc = subprocess.Popen(
        [sys.executable,
         '%s/../../scripts/scons_helpers/parse-version.py' %
         os.path.dirname(os.path.realpath(__file__))],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT)
    return tuple(proc.stdout.read().decode().strip().split('.'))

# -- General configuration ------------------------------------------------

extensions = [
    'sphinx.ext.autodoc',
    'sphinx.ext.coverage',
    'sphinx.ext.mathjax',
    'breathe',
]

templates_path = []

source_suffix = ['.rst']
exclude_patterns = []

master_doc = 'index'

project = u'Roc Toolkit'
copyright = u'%s, Roc Streaming authors' % datetime.datetime.now().year
author = u'Roc Streaming authors'

version_tuple = get_version()

version = 'Roc Toolkit %s' % '.'.join(version_tuple[:2])
release = '%s' % '.'.join(version_tuple)

today_fmt = '%Y'

pygments_style = 'sphinx'

todo_include_todos = False

# -- Options for Breathe ----------------------------------------------

breathe_projects = { 'roc': '../../build/docs/public_api/xml' }

breathe_default_project = 'roc'
breathe_domain_by_extension = {'h': 'c'}

# -- Options for HTML output ----------------------------------------------

html_title = '%s %s' % (project, release)

html_theme = 'nature'

html_logo = '../images/logo80.png'

html_sidebars = {
   '**': ['globaltoc.html', 'searchbox.html'],
}

html_context = {
    'css_files': ['_static/roc.css'],
    'script_files': ['/analytics.js'],
}

html_static_path = ['_static']

html4_writer = True

# -- Options for manual page output ---------------------------------------

man_pages = [
    ('manuals/roc_send', 'roc-send', u'send real-time audio', [], 1),
    ('manuals/roc_recv', 'roc-recv', u'receive real-time audio', [], 1),
    ('manuals/roc_conv', 'roc-conv', u'convert audio', [], 1),
]
