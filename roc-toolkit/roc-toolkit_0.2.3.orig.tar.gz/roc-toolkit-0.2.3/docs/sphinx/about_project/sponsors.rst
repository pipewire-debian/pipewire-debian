Sponsors
********

Big thanks to people and companies who have sponsored this project!

Becoming a sponsor
==================

If you would like to support the project financially, you can use one of the following services for one-time or recurring donations. Your donations allow to allocate more time for development and buy hardware for testing. Thank you!

* `Open Collective <https://opencollective.com/roc-streaming>`_
* `Liberapay <https://liberapay.com/roc-streaming>`_

If you or your company wants to sponsor development of a particular feature, you're welcome to contact us through the public :ref:`mailing list <mailing_list>` or write directly to one of the :ref:`maintainers <maintainers>`.

Corporate sponsors
==================

.. image:: https://i.imgur.com/qdWkfkK.png
   :height: 150px
   :target: https://www.boring.tech/
