Publications
************

This page lists some known publications, ordered by the publication date, that might be useful in  addition to the documentation.

* `"Updated tutorial for Roc 0.2" <https://gavv.net/articles/roc-tutorial-0.2/>`_ *by Victor Gaydov*

* `"Roc Toolkit 0.2 released" <https://gavv.net/articles/roc-0.2/>`_ *by Victor Gaydov*

* `"A step-by-step tutorial for live audio streaming with Roc" <https://gavv.net/articles/roc-tutorial/>`_ *by Victor Gaydov*

* `"Roc 0.1 released: real-time streaming over the network" <https://gavv.net/articles/roc-0.1/>`_ *by Victor Gaydov*

* `"Working on a new network transport for PulseAudio and ALSA" <https://gavv.net/articles/new-network-transport/>`_ *by Victor Gaydov*
