Roc Toolkit documentation
*************************

Welcome to `Roc Toolkit <https://roc-streaming.org/>`_ documentation!

.. toctree::
   :caption: Table of Contents:
   :maxdepth: 2
   :titlesonly:

   about_project
   building
   running
   api
   manuals
   portability
   internals
   development
