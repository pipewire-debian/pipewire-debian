Authors
*******

Thanks to all who have contributed to the project!

This page provides a (probably incomplete) list of people who have submitted changes to our repositories, ordered by the date of the first submission. If you did so, feel free to add yourself to the list manually or by running ``scripts/authors.sh``.

Maintainers
===========

Core team
~~~~~~~~~

* Mikhail Baranov <baranov.mv@gmail.com>
* Victor Gaydov <victor@enise.org>
* Dmitriy Shilin <dshil@fastmail.com>

Go team
~~~~~~~

* Asal Mirzaieva <asalle.kim@gmail.com>

Java team
~~~~~~~~~

* Arella Matteo <arella.matteo.95@gmail.com>
* Andrey Bushmin <diskbu@yandex.ru>

Contributors
============

* Andrew Petelin <adrianopol@gmail.com>
* zenuo <zenuo@protonmail.com>
* Soul Trace <S-trace@list.ru>
* Paul Malcolm <paul.malcolm@l3t.com>
* Thomas Dwyer <tdwyer1990@gmail.com>
* Hrishikesh Suresh <hrishikesh123s@gmail.com>
* Changyoung Koh <gkcy1019@gmail.com>
* Alexandre Magaud <alexandre.magaud@gmail.com>
* Cristobal Miranda <cristobal.miranda.tt@gmail.com>
* Rohan Kumar <rohank.ce@gmail.com>
* Jonathan Sieber <mail@strfry.org>
* Gareth Marlow <gareth@eqsystems.io>
* Ivan <miklecivan3@gmail.com>
* Suiyi Fu <fusuiyi123@gmail.com>
* Vladimir Panov <quest201114@yandex.ru>
* Diego Coladas Mato <dcoladasmato@gmail.com>
* Miguel Victoria <miguelvicvil@gmail.com>
