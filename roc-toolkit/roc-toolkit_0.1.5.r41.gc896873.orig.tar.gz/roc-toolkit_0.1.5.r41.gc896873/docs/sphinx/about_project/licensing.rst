Licensing
*********

Roc source code, except PulseAudio modules, is licensed under `MPL-2.0 <https://www.mozilla.org/en-US/MPL/2.0/>`_.

Roc PulseAudio modules are licensed under `LGPL-2.1 <https://www.gnu.org/licenses/old-licenses/lgpl-2.1.en.html>`_.

If Roc is built with OpenFEC support enabled, it must be distributed under a license compatible with `CeCILL <http://openfec.org/patents.html>`_, a GPL-like and GPL-compatible license used for OpenFEC.
