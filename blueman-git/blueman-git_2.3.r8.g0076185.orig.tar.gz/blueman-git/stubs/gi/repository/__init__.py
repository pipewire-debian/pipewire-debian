from typing import Any

AppIndicator3: Any
NM: Any
